#pragma once
enum class Behaviour
{
	KinematicSeek,
	KinematicFlee,
	KinematicArrive,
	KinematicWander,
	Seek,
	Flee,
	Arrive,
	Allign,
	VelocityMatch,
	Pursue,
	Evade,
	Face,
	LookWhereYoureGoing,
	Wander,
	FollowPath
};